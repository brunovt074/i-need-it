# i-need-it

Three columns to organize your life: **I need** (urgent · today–2 weeks), **I want** (mid-term · 2 weeks–6 months), and **I wish** (long-term · 6 months+). A paper framework turned into an app.

> **Status:** Design prototype. The Kotlin / Jetpack Compose implementation is the next step.

---

## Repo layout

```
design/                       ← interactive design prototype (HTML/CSS/JS)
  index.html                  ← design canvas — open this in a browser
  resources/lang/{es,en}.json ← i18n dictionaries (single source of truth)
  styles/tokens.css           ← all design tokens (colors, fonts, spacing, motion)
  paper-ui.jsx                ← shared UI primitives (cards, chips, top bar…)
  mobile-screens.jsx          ← the four explored mobile layouts + chosen MainDashboard
  desktop-screen.jsx          ← desktop dashboard (3-column board with temporal arrow)
  modal-screens.jsx           ← create / view / edit modals (bottom-sheet + centered)
  settings-screen.jsx         ← language, theme, sync, account
  data.js                     ← sample dataset used by every screen
  i18n.js                     ← lightweight runtime locale loader
  design-canvas.jsx           ← infra: pan/zoom canvas for presenting variants
  tweaks-panel.jsx            ← infra: in-page knobs (locale, theme, color intensity)
```

> Open `design/index.html` in a browser to walk every screen. Pan with two fingers / drag, pinch to zoom. Double-click any artboard to focus it; ←/→/Esc to navigate.

---

## Visual system — paper / notebook

Fiel al sketch en papel: fondo crema, tinta rojiza, retícula de puntos, hojas con borde fino.

| Token group   | Light                                 | Dark                                |
| ------------- | ------------------------------------- | ----------------------------------- |
| paper bg      | `#f1e8d4`                             | `#1d1611`                           |
| ink           | `#7a2e1f`                             | `#ecd2b2`                           |
| col-need      | `#8a2818`  (most urgent / saturated)  | `#e88f6f`                           |
| col-want      | `#a04a37`                             | `#d9a583`                           |
| col-wish      | `#b6735a`  (calm / peachy)            | `#c5b394`                           |

The three columns share the same hue family — only saturation drops left-to-right, matching the natural sense of urgency. Intensity is tweakable (sutil · medio · vivo) and persists per user.

### Typography
- **Newsreader** italic — display (column titles, item names)
- **Geist** — body, controls
- **Caveat** — handwritten accent, used only for prompts and empty states
- **JetBrains Mono** — tabular numbers (costs, counts)

### Spacing / radii / motion
All in `styles/tokens.css`. 4 px base, soft radii (`r-md=8`, `r-lg=14`, `r-pill=999`), one easing for utility (`ease-out`) and one for snappy spring entrances (`ease-spring`).

---

## Layouts explored

The mobile challenge was: show three columns on a vertical screen without losing context. Four approaches were prototyped:

| Variant         | Status     | Idea                                                                    |
| --------------- | ---------- | ----------------------------------------------------------------------- |
| **Accordion**   | ✅ Default | All three columns visible as collapsible sections. Tap to expand.       |
| **Fan**         | ✅ Switch  | Three "paper sheets" stacked with fan tilt. Tap a peeking tab to flip.  |
| Tabs            | ❌ Discarded | Segmented control + one column visible at a time.                       |
| Horizontal swipe | ❌ Discarded | Carousel with peek of the next column on the right edge.                |

**Layout switcher** lives in the top bar (outlined icon next to the search glyph) and persists per user via `localStorage` (in the real app: local store table).

---

## Architecture (Compose target)

| Concern         | Prototype                                  | Real app (Kotlin / Compose)                   |
| --------------- | ------------------------------------------ | --------------------------------------------- |
| i18n            | `resources/lang/{es,en}.json` + `i18n.js`  | `res/values/strings.xml` + `values-es/`       |
| Theme tokens    | `styles/tokens.css` CSS custom properties  | `MaterialTheme` + a custom `Tokens` object    |
| Local store     | Hard-coded `data.js` fixture               | Room (SQLite) — entries + soft-deleted items  |
| Sync            | (mocked — "synced" indicator only)         | Supabase + Realtime · last-write-wins + audit |
| Layout pref     | `localStorage["i-need-it.layout"]`         | `DataStore` user preferences                  |
| Locale          | `localStorage["i-need-it.locale"]`         | `AppCompatDelegate.setApplicationLocales`     |

### Data model (suggested)

```kotlin
data class Entry(
    val id: String,
    val column: Column,            // NEED, WANT, WISH
    val name: String,              // required
    val timeKey: String?,          // "today" | "thisWeek" | … | "specificDate"
    val specificDate: LocalDate?,  // only when timeKey == specificDate
    val cost: Money?,              // amount + currency
    val place: String?,
    val tags: List<TagKey>,        // health, home, hobby, …
    val completedAt: Instant?,     // null = active
    val createdAt: Instant,
    val updatedAt: Instant,
)
```

`column` is the primary partition; everything else is metadata. Moving between columns = updating one field. Marking done = setting `completedAt`. History view = list where `completedAt != null`.

---

## i18n contract

**Rule:** no string is hardcoded in UI code. Every label flows through `t("namespace.key")`.

Adding a new string:
1. Add the key to **both** `resources/lang/es.json` and `resources/lang/en.json`.
2. Use it in components via `t('your.new.key')`.

For Compose, the same JSON tree maps cleanly to a sealed `Strings` object or a key-based `stringResource()` lookup.

---

## Roadmap

- [ ] **Now** · review and approve design direction (this prototype)
- [ ] **Next** · Compose project scaffold — theme, tokens, navigation graph
- [ ] **Next** · Local-only MVP — Room store, accordion dashboard, create modal
- [ ] **Then** · Fan layout + layout switcher
- [ ] **Then** · Supabase + sync indicator
- [ ] **Later** · Search/filter, tags, completed history
- [ ] **Later** · Web (Compose Multiplatform for web, or Next.js companion)

---

## License

TBD — private project for now.
