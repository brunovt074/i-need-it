// data.js — sample dataset for the prototype.
// In the real app this comes from a local store (Room/SQLite) synced with
// Supabase. Here it's a static fixture so every screen renders identical
// content — keeps the canvas comparison apples-to-apples.

window.SAMPLE_ITEMS = {
  need: [
    { id: 'n1', name: 'Pasta de dientes',  time: 'today',     cost: { amount: 800,   currency: 'ars' }, place: 'Farmacia',  tags: ['health'] },
    { id: 'n2', name: 'Comenzar gym',      time: 'thisWeek',                                                                 tags: ['fitness', 'health'] },
    { id: 'n3', name: 'Dormir 8 horas',                                                                                       tags: ['health'] },
    { id: 'n4', name: 'Renovar DNI',       time: 'twoWeeks',                                                place: 'Registro Civil' },
    { id: 'n5', name: 'Pagar internet',    time: 'today',     cost: { amount: 35000, currency: 'ars' } },
    { id: 'n6', name: 'Cargar la SUBE',                       cost: { amount: 5000,  currency: 'ars' } },
  ],
  want: [
    { id: 'w1', name: 'PC desktop',                          time: 'threeMonths', cost: { amount: 1200, currency: 'usd' }, tags: ['hobby', 'work'] },
    { id: 'w2', name: 'Ir al campo dos veces al mes',        time: 'thisMonth',                                            place: 'Sierras', tags: ['hobby'] },
    { id: 'w3', name: 'Curso de inglés avanzado',            time: 'sixMonths',   cost: { amount: 80,   currency: 'usd' }, tags: ['study'] },
    { id: 'w4', name: 'Bicicleta nueva',                     time: 'sixMonths',   cost: { amount: 450,  currency: 'usd' }, tags: ['fitness'] },
    { id: 'w5', name: 'Visitar a la abuela en Rosario',      time: 'thisMonth',                                            place: 'Rosario', tags: ['family'] },
  ],
  wish: [
    { id: 's1', name: 'Automóvil',         time: 'oneYear',      cost: { amount: 15000, currency: 'usd' },                              tags: ['home'] },
    { id: 's2', name: 'Clases de parapente', time: 'oneYear',    cost: { amount: 600,   currency: 'usd' }, place: 'Bariloche',          tags: ['hobby', 'travel'] },
    { id: 's3', name: 'Viajar a Japón',    time: 'moreThanYear', cost: { amount: 5000,  currency: 'usd' },                              tags: ['travel'] },
    { id: 's4', name: 'Mudarme a una casa con patio', time: 'moreThanYear',                                                              tags: ['home', 'family'] },
  ],
};

// Column metadata in source order. The columns array drives every layout —
// add/remove a column here and every variant updates.
window.COLUMNS = [
  { key: 'need', cssVar: '--col-need', wash: '--col-need-wash', soft: '--col-need-soft', border: '--col-need-border' },
  { key: 'want', cssVar: '--col-want', wash: '--col-want-wash', soft: '--col-want-soft', border: '--col-want-border' },
  { key: 'wish', cssVar: '--col-wish', wash: '--col-wish-wash', soft: '--col-wish-soft', border: '--col-wish-border' },
];

// Format a money amount with locale grouping. `currency` is our 3-letter
// lowercase key (matching i18n.currency.*).
window.formatMoney = function (cost, locale) {
  if (!cost || cost.amount == null) return '';
  const sym = ({ ars: '$', usd: 'US$', eur: '€', brl: 'R$', clp: 'CL$' })[cost.currency] || '';
  const n = Math.round(cost.amount).toLocaleString(locale === 'es' ? 'es-AR' : 'en-US');
  return `${sym} ${n}`;
};

// Map a time-chip key to a compact label for inline display on cards.
// Long forms live in the modal; cards get an abbreviated tag.
window.timeLabelShort = function (key, t) {
  if (!key) return '';
  if (key === 'today') return t('time.today');
  if (key === 'thisWeek') return t('time.thisWeek');
  if (key === 'twoWeeks') return t('time.twoWeeks');
  if (key === 'thisMonth') return t('time.thisMonth');
  if (key === 'threeMonths') return '3m';
  if (key === 'sixMonths') return '6m';
  if (key === 'oneYear') return '1a';
  if (key === 'moreThanYear') return '+1a';
  return key;
};
