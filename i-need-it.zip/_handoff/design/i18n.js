// i18n.js — runtime locale loader for i-need-it
//
// Single source of truth: resources/lang/{locale}.json
// Public API on window.i18n:
//   await i18n.init()                    // pre-load default + alt locale
//   i18n.t('columns.need.title')         // translate dot-path
//   i18n.t('history.completedOn',{date}) // {token} interpolation
//   i18n.setLocale('en' | 'es')          // hot-swap; broadcasts a 'i18n:change' event on window
//   i18n.locale                          // current code
//
// React side: useI18n() hook (defined below) returns {t, locale, setLocale}
// and re-renders subscribers when locale changes.

(function () {
  const SUPPORTED = ['es', 'en'];
  const DEFAULT = 'es';
  const store = {}; // { es: {...}, en: {...} }

  function getPath(obj, path) {
    return path.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), obj);
  }

  function interpolate(str, vars) {
    if (!vars || typeof str !== 'string') return str;
    return str.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? String(vars[k]) : `{${k}}`));
  }

  async function loadLocale(code) {
    if (store[code]) return store[code];
    try {
      const res = await fetch(`./resources/lang/${code}.json`);
      if (!res.ok) throw new Error(`failed to load ${code}: ${res.status}`);
      store[code] = await res.json();
      return store[code];
    } catch (err) {
      console.error('[i18n]', err);
      store[code] = {};
      return store[code];
    }
  }

  const api = {
    locale: localStorage.getItem('i-need-it.locale') || DEFAULT,
    supported: SUPPORTED,

    async init() {
      // Load current + the other supported locale up front so toggle is instant.
      await Promise.all(SUPPORTED.map(loadLocale));
      return api;
    },

    t(path, vars) {
      const dict = store[api.locale] || {};
      const v = getPath(dict, path);
      if (v === undefined) {
        // Fallback: try the default locale, then return the path itself.
        const fb = getPath(store[DEFAULT] || {}, path);
        if (fb !== undefined) return interpolate(fb, vars);
        return path;
      }
      return interpolate(v, vars);
    },

    setLocale(code) {
      if (!SUPPORTED.includes(code) || code === api.locale) return;
      api.locale = code;
      try { localStorage.setItem('i-need-it.locale', code); } catch (e) {}
      window.dispatchEvent(new CustomEvent('i18n:change', { detail: { locale: code } }));
    },
  };

  window.i18n = api;

  // React hook — assumes React is loaded on the page.
  window.useI18n = function useI18n() {
    const [locale, setLocaleState] = React.useState(api.locale);
    React.useEffect(() => {
      const onChange = (e) => setLocaleState(e.detail.locale);
      window.addEventListener('i18n:change', onChange);
      return () => window.removeEventListener('i18n:change', onChange);
    }, []);
    return {
      locale,
      setLocale: api.setLocale,
      t: (path, vars) => api.t(path, vars),
    };
  };
})();
