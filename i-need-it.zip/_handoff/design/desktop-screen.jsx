// desktop-screen.jsx — desktop dashboard (1280 × 760)
//
// Fiel al sketch: tres columnas, encerradas en un marco rojizo, con la flecha
// temporal arriba indicando progresión de izquierda (urgente) a derecha
// (lejano). Cada item es una línea tipográfica con sus íconos meta a la
// derecha. Click en un ítem abre el modal central.

function DesktopDashboard({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light' }) {
  return (
    <div data-theme={theme} style={{
      width: '100%', height: '100%',
      background: 'var(--paper-bg)',
      backgroundImage: 'var(--paper-dots)',
      backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Top bar */}
      <header style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 36px 14px',
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
          <span style={{
            fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
            fontSize: 30, letterSpacing: '-0.025em', color: 'var(--ink)',
            whiteSpace: 'nowrap',
          }}>i-need-it</span>
          <span style={{ fontSize: 12, color: 'var(--ink-faded)' }}>{t('app.tagline')}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* Search field — inline, paper style */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '7px 12px',
            border: '1px solid var(--ink-whisper)',
            borderRadius: 'var(--r-pill)',
            background: 'var(--paper-bg-tint)',
            minWidth: 260,
            color: 'var(--ink-faded)',
          }}>
            {pui.iconSearch}
            <span style={{ fontSize: 12 }}>{t('search.placeholder')}</span>
          </div>
          <IconButton onClick={() => {}} title={t('actions.filter')}>{pui.iconFilter}</IconButton>
          <LocaleSwitch t={t} locale={locale} onChange={onLocale} />
          <IconButton onClick={onSettings} title={t('settings.title')}>{pui.iconSettings}</IconButton>
        </div>
      </header>

      {/* Sketch frame with three columns + temporal arrow */}
      <main style={{ flex: 1, padding: '12px 36px 36px', minHeight: 0, display: 'flex' }}>
        <div style={{
          flex: 1,
          border: '2px solid var(--ink)',
          borderRadius: 3,
          position: 'relative',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr 1fr',
          background: 'var(--paper-bg-tint)',
        }}>
          {/* The temporal arrow that runs along the TOP of the frame — fiel al sketch */}
          <div style={{
            position: 'absolute',
            top: -10, right: -12,
            display: 'flex', alignItems: 'center', gap: 6,
            color: 'var(--ink)',
            background: 'var(--paper-bg)',
            padding: '0 8px',
          }}>
            <span style={{ fontFamily: 'var(--font-hand)', fontSize: 16, color: 'var(--ink-soft)' }}>
              tiempo
            </span>
            <span style={{ display: 'inline-flex' }}>{pui.iconArrow}</span>
          </div>

          {COLUMNS.map((c, i) => {
            const tone = `var(${c.cssVar})`;
            const items = SAMPLE_ITEMS[c.key];
            return (
              <div key={c.key} style={{
                padding: '24px 26px 16px',
                borderRight: i < 2 ? '1.5px solid var(--ink)' : 'none',
                display: 'flex', flexDirection: 'column',
                background: `var(${c.wash})`,
                minHeight: 0,
              }}>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
                  <h2 style={{
                    margin: 0,
                    fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
                    fontSize: 28, color: tone, letterSpacing: '-0.02em', lineHeight: 1,
                  }}>{t(`columns.${c.key}.title`)}</h2>
                  <span className="tabular" style={{ fontSize: 12, color: 'var(--ink-faded)' }}>{items.length}</span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-faded)', marginBottom: 14, letterSpacing: '0.02em' }}>
                  {t(`columns.${c.key}.subtitle`)}
                </div>

                <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', marginRight: -8, paddingRight: 8 }}>
                  {items.map((it) => (
                    <ItemCard key={it.id} item={it} onClick={() => onItemTap && onItemTap(it)} locale={locale} />
                  ))}
                  <AddRow promptText={t(`columns.${c.key}.promptCta`)} onClick={() => onAdd && onAdd(c.key)} color={tone} />
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* footer hint */}
      <footer style={{
        padding: '10px 36px 18px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        color: 'var(--ink-faded)', fontSize: 11,
      }}>
        <span>{t('settings.synced')}  ·  {SAMPLE_ITEMS.need.length + SAMPLE_ITEMS.want.length + SAMPLE_ITEMS.wish.length} {locale === 'es' ? 'asientos' : 'entries'}</span>
        <span>{locale === 'es' ? 'Tap en un asiento para ver detalles · Tap en una zona vacía para agregar' : 'Tap an entry for details · Tap an empty zone to add'}</span>
      </footer>
    </div>
  );
}

Object.assign(window, { DesktopDashboard });
