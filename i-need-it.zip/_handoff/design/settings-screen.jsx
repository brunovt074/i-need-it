// settings-screen.jsx — Mobile settings (language, theme, sync, about)

function SettingsScreen({ t, locale, onLocale, theme = 'light', onTheme }) {
  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--paper-bg)', backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)' }}>

      {/* Header */}
      <div style={{ padding: '14px 18px 8px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <IconButton title={t('actions.back')}>
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 3L4 8l5 5"/><path d="M4 8h10"/>
          </svg>
        </IconButton>
        <span style={{
          fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
          fontSize: 22, letterSpacing: '-0.02em',
        }}>{t('settings.title')}</span>
      </div>

      <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', padding: '12px 18px 24px' }}>
        {/* LANGUAGE */}
        <SettingsSection label={t('settings.language')}>
          <SegmentedRow
            value={locale}
            options={[
              { key: 'es', label: t('settings.languageEs') },
              { key: 'en', label: t('settings.languageEn') },
            ]}
            onChange={onLocale}
          />
        </SettingsSection>

        {/* THEME */}
        <SettingsSection label={t('settings.theme')}>
          <SegmentedRow
            value={theme}
            options={[
              { key: 'light', label: t('settings.themeLight') },
              { key: 'dark',  label: t('settings.themeDark')  },
              { key: 'auto',  label: t('settings.themeAuto')  },
            ]}
            onChange={onTheme}
          />
        </SettingsSection>

        {/* SYNC */}
        <SettingsSection label={t('settings.sync')}>
          <Row
            left={(
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{
                  width: 8, height: 8, borderRadius: 4,
                  background: 'var(--success)',
                }} />
                <span>{t('settings.synced')}</span>
              </div>
            )}
            right={<span style={{ fontSize: 11, color: 'var(--ink-faded)' }}>hace 2 min</span>}
          />
          <Row
            left={<span>Supabase · brunovt074</span>}
            right={pui.iconChevron}
          />
        </SettingsSection>

        {/* ACCOUNT */}
        <SettingsSection label={t('settings.account')}>
          <Row left={<span>bruno@example.com</span>} right={pui.iconChevron} />
          <Row left={<span style={{ color: 'var(--col-need)' }}>{t('settings.signOut')}</span>} />
        </SettingsSection>

        {/* ABOUT */}
        <SettingsSection label={t('settings.about')}>
          <Row left={<span style={{ color: 'var(--ink-faded)' }}>{t('settings.version')}</span>}
               right={<span className="tabular" style={{ color: 'var(--ink-faded)', fontSize: 12 }}>0.1.0</span>} />
        </SettingsSection>

        {/* Footer signature */}
        <div style={{ textAlign: 'center', marginTop: 22, color: 'var(--ink-faded)',
          fontFamily: 'var(--font-hand)', fontSize: 18 }}>
          un framework de papel, en tu bolsillo
        </div>
      </div>

      <BottomNav t={t} current="settings" />
    </div>
  );
}

function SettingsSection({ label, children }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{
        fontSize: 11, fontWeight: 600, letterSpacing: '0.08em',
        textTransform: 'uppercase', color: 'var(--ink-faded)',
        marginBottom: 8, paddingLeft: 4,
      }}>{label}</div>
      <div style={{
        background: 'var(--paper-bg-tint)',
        border: '1px solid var(--ink-whisper)',
        borderRadius: 12,
        overflow: 'hidden',
      }}>{children}</div>
    </div>
  );
}

function Row({ left, right }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '12px 14px',
      borderBottom: '1px solid var(--ink-whisper)',
      fontSize: 14,
      cursor: 'pointer',
    }}>
      <div>{left}</div>
      <div style={{ color: 'var(--ink-faded)' }}>{right}</div>
    </div>
  );
}

function SegmentedRow({ value, options, onChange }) {
  return (
    <div style={{
      display: 'flex',
      padding: 4,
      gap: 2,
    }}>
      {options.map((o) => {
        const active = o.key === value;
        return (
          <button key={o.key} onClick={() => onChange && onChange(o.key)}
            style={{
              flex: 1,
              border: 'none', cursor: 'pointer',
              padding: '8px 10px',
              borderRadius: 8,
              background: active ? 'var(--ink)' : 'transparent',
              color: active ? 'var(--paper-bg)' : 'var(--ink-soft)',
              fontFamily: 'inherit',
              fontSize: 12, fontWeight: 600,
              letterSpacing: '0.02em',
              transition: 'background var(--dur-fast), color var(--dur-fast)',
            }}>{o.label}</button>
        );
      })}
    </div>
  );
}

Object.assign(window, { SettingsScreen });
