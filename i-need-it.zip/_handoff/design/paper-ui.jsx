// paper-ui.jsx — shared UI primitives for i-need-it
//
// Components export to window at the bottom so individual screen scripts
// (mobile-screens.jsx, desktop-screen.jsx, etc.) can pick them up without
// re-import. Style objects are PREFIXED (pui*) per the multi-file rules.

const pui = {
  // Small SVG icon set, all 1.5px stroked, matching pen/ink feel.
  iconCost: (
    <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 2v12M11 4.5C10.5 3.5 9.3 3 8 3c-1.7 0-3 .9-3 2.2 0 1.3 1.3 2 3 2.3 1.7.3 3 1 3 2.3 0 1.3-1.3 2.2-3 2.2-1.3 0-2.5-.5-3-1.5"/>
    </svg>
  ),
  iconTime: (
    <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="8" cy="8" r="6"/><path d="M8 4.5V8l2.2 1.4"/>
    </svg>
  ),
  iconPlace: (
    <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 14s-5-4.5-5-8.3A5 5 0 0 1 8 1a5 5 0 0 1 5 4.7C13 9.5 8 14 8 14z"/><circle cx="8" cy="5.7" r="1.8"/>
    </svg>
  ),
  iconTag: (
    <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 2h6l6 6-6 6-6-6V2z"/><circle cx="5" cy="5" r="1"/>
    </svg>
  ),
  iconPlus: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
      <path d="M8 3v10M3 8h10"/>
    </svg>
  ),
  iconSearch: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
      <circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/>
    </svg>
  ),
  iconFilter: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
      <path d="M2 4h12M4 8h8M6 12h4"/>
    </svg>
  ),
  iconSettings: (
    <svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="8" cy="8" r="2"/>
      <path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4"/>
    </svg>
  ),
  iconCheck: (
    <svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 8.5L6.5 12 13 4"/>
    </svg>
  ),
  iconClose: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
      <path d="M4 4l8 8M12 4l-8 8"/>
    </svg>
  ),
  iconArrow: (
    <svg viewBox="0 0 32 12" width="32" height="12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 6h28M24 1l5 5-5 5"/>
    </svg>
  ),
  iconChevron: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 3l5 5-5 5"/>
    </svg>
  ),
  iconHome: (
    <svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2.5 7L8 2.5 13.5 7v6.5h-3v-4h-5v4h-3V7z"/>
    </svg>
  ),
  iconDone: (
    <svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2.5" y="2.5" width="11" height="11" rx="1.5"/><path d="M5 8l2 2 4-4"/>
    </svg>
  ),
  // Layout switcher icons. The button shows the icon of the OTHER layout —
  // i.e. when you're in the accordion view, you see the fan icon (action:
  // "switch to fan"), and vice-versa.
  iconLayoutAccordion: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2.5" y="3"  width="11" height="2.4" rx="0.6"/>
      <rect x="2.5" y="6.8" width="11" height="2.4" rx="0.6"/>
      <rect x="2.5" y="10.6" width="11" height="2.4" rx="0.6"/>
    </svg>
  ),
  iconLayoutFan: (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      {/* three small "cards" fanned out from a base point */}
      <g transform="translate(8 13)">
        <rect x="-2.4" y="-9" width="4.8" height="9" rx="0.8" transform="rotate(-16)"/>
        <rect x="-2.4" y="-9" width="4.8" height="9" rx="0.8"/>
        <rect x="-2.4" y="-9" width="4.8" height="9" rx="0.8" transform="rotate(16)"/>
      </g>
    </svg>
  ),
};

// ── PhoneFrame ───────────────────────────────────────────────────────────
// A minimal device-shaped paper card. No iOS/Android branding — focus on
// the app. Width × height is the inner viewport; the frame wraps it with
// thin rust border + rounded corners + faint hardware indicators.
function PhoneFrame({ width = 360, height = 760, theme = 'light', children, label }) {
  return (
    <div data-theme={theme}
      style={{
        width: width + 24, height: height + 24,
        padding: 12,
        borderRadius: 42,
        background: 'var(--paper-bg-tint)',
        border: '1.5px solid var(--ink-faded)',
        boxShadow: '0 30px 60px -20px var(--paper-shadow), 0 4px 12px var(--paper-shadow)',
        position: 'relative',
        boxSizing: 'border-box',
        fontFamily: 'var(--font-body)',
        color: 'var(--ink)',
        display: 'inline-block',
      }}>
      {/* speaker pill */}
      <div style={{
        position: 'absolute', top: 18, left: '50%', transform: 'translateX(-50%)',
        width: 44, height: 4, borderRadius: 2, background: 'var(--ink-faded)', opacity: 0.5,
      }} />
      <div style={{
        width, height,
        borderRadius: 30,
        overflow: 'hidden',
        position: 'relative',
        background: 'var(--paper-bg)',
        backgroundImage: 'var(--paper-dots)',
        backgroundSize: 'var(--paper-dot-size)',
      }}>
        {children}
      </div>
    </div>
  );
}

// ── DesktopFrame ─────────────────────────────────────────────────────────
function DesktopFrame({ width = 1280, height = 760, theme = 'light', children }) {
  return (
    <div data-theme={theme}
      style={{
        width, height,
        background: 'var(--paper-bg)',
        backgroundImage: 'var(--paper-dots)',
        backgroundSize: 'var(--paper-dot-size)',
        fontFamily: 'var(--font-body)',
        color: 'var(--ink)',
        position: 'relative',
        overflow: 'hidden',
      }}>
      {children}
    </div>
  );
}

// ── Chip — small pill (used for tags, time chips, filters) ──────────────
function Chip({ children, active, onClick, color = 'var(--ink)', outlined, style }) {
  return (
    <button onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 4,
        padding: '3px 9px',
        border: `1px solid ${active ? color : 'var(--ink-whisper)'}`,
        background: active ? color : (outlined ? 'transparent' : 'var(--paper-bg-tint)'),
        color: active ? 'var(--paper-bg)' : color,
        borderRadius: 'var(--r-pill)',
        fontSize: 11,
        lineHeight: 1.2,
        fontWeight: 500,
        cursor: 'pointer',
        fontFamily: 'inherit',
        whiteSpace: 'nowrap',
        transition: 'background var(--dur-fast), color var(--dur-fast), border-color var(--dur-fast)',
        ...style,
      }}>
      {children}
    </button>
  );
}

// ── MetaIcons — tiny indicators row shown on the right of an ItemCard ───
function MetaIcons({ item, locale = 'es' }) {
  const has = (k) => item[k] != null;
  if (!has('time') && !has('cost') && !has('place')) return null;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 7,
      color: 'var(--ink-faded)',
      flexShrink: 0,
    }}>
      {has('cost') && <span title="cost" style={{ display: 'inline-flex' }}>{pui.iconCost}</span>}
      {has('time') && <span title="time" style={{ display: 'inline-flex' }}>{pui.iconTime}</span>}
      {has('place') && <span title="place" style={{ display: 'inline-flex' }}>{pui.iconPlace}</span>}
    </div>
  );
}

// ── ItemCard — the row in a column. Shows ONLY the name + meta icons.
// Tap surface = full row. expanded prop optional (for "selected" highlight).
function ItemCard({ item, color = 'var(--ink)', onClick, expanded, locale = 'es', dense = false }) {
  return (
    <button onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        width: '100%',
        textAlign: 'left',
        padding: dense ? '8px 2px' : '11px 4px',
        background: expanded ? 'var(--ink-whisper)' : 'transparent',
        border: 'none',
        borderRadius: 4,
        cursor: 'pointer',
        color: color,
        fontFamily: 'var(--font-display)',
        fontSize: dense ? 15 : 17,
        fontWeight: 450,
        letterSpacing: '-0.005em',
        lineHeight: 1.25,
        borderBottom: '1px solid var(--ink-whisper)',
        transition: 'background var(--dur-fast)',
      }}
      onMouseEnter={(e) => { if (!expanded) e.currentTarget.style.background = 'var(--ink-whisper)'; }}
      onMouseLeave={(e) => { if (!expanded) e.currentTarget.style.background = 'transparent'; }}>
      <span style={{
        flex: 1, minWidth: 0,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
      }}>{item.name}</span>
      <MetaIcons item={item} locale={locale} />
    </button>
  );
}

// ── AddRow — the “tap a blank part of the column to add” affordance.
// Lives at the bottom of each column. The whole empty area below it is
// also clickable in practice — this row makes that explicit.
function AddRow({ promptText, onClick, color = 'var(--ink-faded)' }) {
  return (
    <button onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        width: '100%',
        padding: '12px 4px',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        color: color,
        fontFamily: 'var(--font-hand)',
        fontSize: 22,
        fontWeight: 500,
        textAlign: 'left',
        lineHeight: 1,
        opacity: 0.85,
        transition: 'opacity var(--dur-fast)',
      }}
      onMouseEnter={(e) => (e.currentTarget.style.opacity = 1)}
      onMouseLeave={(e) => (e.currentTarget.style.opacity = 0.85)}>
      <span style={{ display: 'inline-flex' }}>{pui.iconPlus}</span>
      <span>{promptText}</span>
    </button>
  );
}

// ── ColumnTitle — header shown above each column. Newsreader title +
// quiet bilingual hint (the user's sketch has both labels).
function ColumnTitle({ titleKey, color, t, showSubtitle = true, size = 'lg' }) {
  const sizes = {
    lg: { title: 26, sub: 12 },
    md: { title: 22, sub: 11 },
    sm: { title: 18, sub: 10 },
  }[size];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <h2 style={{
        margin: 0,
        fontFamily: 'var(--font-display)',
        fontStyle: 'italic',
        fontWeight: 500,
        fontSize: sizes.title,
        color: color,
        letterSpacing: '-0.02em',
        lineHeight: 1,
      }}>{t(`columns.${titleKey}.title`)}</h2>
      {showSubtitle && (
        <div style={{
          fontSize: sizes.sub,
          color: 'var(--ink-faded)',
          fontWeight: 400,
          letterSpacing: '0.02em',
          lineHeight: 1.3,
        }}>{t(`columns.${titleKey}.subtitle`)}</div>
      )}
    </div>
  );
}

// ── ColumnSurface — a single column block: title + items + add row.
// Used inside every variant. Renders only the content; the host owns sizing.
function ColumnSurface({ colKey, items, color, t, locale, onItemTap, onAdd, dense = false, hideTitle = false }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, minHeight: 0 }}>
      {!hideTitle && <ColumnTitle titleKey={colKey} color={color} t={t} size={dense ? 'sm' : 'md'} />}
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {items.map((it) => (
          <ItemCard key={it.id} item={it} color="var(--ink)" onClick={() => onItemTap && onItemTap(it)} dense={dense} locale={locale} />
        ))}
        <AddRow promptText={t(`columns.${colKey}.promptCta`)} onClick={() => onAdd && onAdd(colKey)} color={color} />
      </div>
    </div>
  );
}

// ── TopBar — common mobile top bar
// `extraActions` mounts BEFORE the search icon — used by MainDashboard to
// drop a layout-switcher button in without subclassing the bar.
function TopBar({ t, locale, onSearch, onSettings, onLocale, theme, onTheme, title, extraActions }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 18px 8px',
      gap: 8,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 7, minWidth: 0 }}>
        <span style={{
          fontFamily: 'var(--font-display)',
          fontStyle: 'italic',
          fontWeight: 500,
          fontSize: 22,
          letterSpacing: '-0.02em',
          color: 'var(--ink)',
          whiteSpace: 'nowrap',
        }}>{title || t('app.title')}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        {extraActions}
        <IconButton onClick={onSearch} title={t('actions.search')}>{pui.iconSearch}</IconButton>
        <LocaleSwitch t={t} locale={locale} onChange={onLocale} />
        <IconButton onClick={onSettings} title={t('settings.title')}>{pui.iconSettings}</IconButton>
      </div>
    </div>
  );
}

function IconButton({ children, onClick, title, color = 'var(--ink-soft)' }) {
  return (
    <button onClick={onClick} title={title}
      style={{
        width: 30, height: 30,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: 'none', background: 'transparent', cursor: 'pointer',
        color, borderRadius: 8,
        transition: 'background var(--dur-fast), color var(--dur-fast)',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--ink-whisper)'; e.currentTarget.style.color = 'var(--ink)'; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = color; }}>
      {children}
    </button>
  );
}

// ── LayoutToggle — visible button to switch dashboard layouts.
// Slightly more prominent than a plain IconButton (thin outline + paper tint)
// so the user reads it as a real toggle, not a passive glyph.
function LayoutToggle({ layout, onToggle, t }) {
  const isAccordion = layout === 'accordion';
  return (
    <button
      onClick={() => onToggle && onToggle(isAccordion ? 'fan' : 'accordion')}
      title={t(isAccordion ? 'actions.layoutFan' : 'actions.layoutList')}
      aria-label={t(isAccordion ? 'actions.layoutFan' : 'actions.layoutList')}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        width: 32, height: 28,
        border: '1px solid var(--ink-whisper)',
        borderRadius: 8,
        background: 'var(--paper-bg-tint)',
        color: 'var(--ink-soft)',
        cursor: 'pointer',
        fontFamily: 'inherit',
        transition: 'background var(--dur-fast), color var(--dur-fast), border-color var(--dur-fast), transform var(--dur-fast)',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--ink-whisper)'; e.currentTarget.style.color = 'var(--ink)'; e.currentTarget.style.borderColor = 'var(--ink-faded)'; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = 'var(--paper-bg-tint)'; e.currentTarget.style.color = 'var(--ink-soft)'; e.currentTarget.style.borderColor = 'var(--ink-whisper)'; }}>
      {isAccordion ? pui.iconLayoutFan : pui.iconLayoutAccordion}
    </button>
  );
}

function LocaleSwitch({ t, locale, onChange }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center',
      border: '1px solid var(--ink-whisper)',
      borderRadius: 'var(--r-pill)',
      padding: 2,
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--ink-soft)',
    }}>
      {['es', 'en'].map((l) => (
        <button key={l}
          onClick={() => onChange && onChange(l)}
          style={{
            border: 'none',
            padding: '3px 8px',
            borderRadius: 'var(--r-pill)',
            cursor: 'pointer',
            background: locale === l ? 'var(--ink)' : 'transparent',
            color: locale === l ? 'var(--paper-bg)' : 'inherit',
            fontWeight: 600,
            fontSize: 10,
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            fontFamily: 'inherit',
            transition: 'background var(--dur-fast), color var(--dur-fast)',
          }}>{l}</button>
      ))}
    </div>
  );
}

// ── BottomNav — Inicio / Hechos / Ajustes
function BottomNav({ t, current = 'dashboard', onChange }) {
  const items = [
    { key: 'dashboard', icon: pui.iconHome, labelKey: 'nav.dashboard' },
    { key: 'history',   icon: pui.iconDone, labelKey: 'nav.history' },
    { key: 'settings',  icon: pui.iconSettings, labelKey: 'nav.settings' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      display: 'flex',
      borderTop: '1px solid var(--ink-whisper)',
      background: 'var(--paper-bg-tint)',
      paddingBottom: 14,
      paddingTop: 8,
    }}>
      {items.map((it) => (
        <button key={it.key} onClick={() => onChange && onChange(it.key)}
          style={{
            flex: 1,
            border: 'none', background: 'transparent', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: current === it.key ? 'var(--ink)' : 'var(--ink-faded)',
            padding: '4px 0',
            fontFamily: 'inherit',
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.02em',
          }}>
          {it.icon}
          <span>{t(it.labelKey)}</span>
        </button>
      ))}
    </div>
  );
}

// ── Tag pill — tiny tag indicator (used in modal/expanded views)
function TagPill({ tagKey, t }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 8px',
      background: 'var(--ink-whisper)',
      color: 'var(--ink-soft)',
      borderRadius: 'var(--r-pill)',
      fontSize: 10.5,
      fontWeight: 500,
      letterSpacing: '0.01em',
    }}>{t(`tags.${tagKey}`)}</span>
  );
}

// Export everything to window for use across other Babel script files.
Object.assign(window, {
  pui,
  PhoneFrame, DesktopFrame,
  Chip, MetaIcons, ItemCard, AddRow,
  ColumnTitle, ColumnSurface,
  TopBar, IconButton, LocaleSwitch, LayoutToggle, BottomNav, TagPill,
});
