// mobile-screens.jsx — four mobile layout explorations
//
// Each variant takes the same shape (t, locale, onLocale, onItemTap, onAdd,
// onSettings, theme) and returns the inner phone-screen content (NOT the
// phone frame — the DesignCanvas artboard plays that role here so designs
// fill the card edge-to-edge).
//
// A — TABS:       industry-standard segmented switcher; one column visible
// B — ACCORDION:  vertical stack of all three columns; one expanded
// C — HSWIPE:     swipeable carousel; peek of the next column on the right
// D — FAN:        the user's idea — three paper cards fanned like a deck

// ── A — TABS ────────────────────────────────────────────────────────────
function MobileTabs({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light' }) {
  const [active, setActive] = React.useState('need');
  const col = COLUMNS.find((c) => c.key === active);
  const items = SAMPLE_ITEMS[active];

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--paper-bg)', backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)' }}>
      <TopBar t={t} locale={locale} onLocale={onLocale} onSearch={() => {}} onSettings={onSettings} />

      {/* Tab strip */}
      <div style={{ display: 'flex', gap: 6, padding: '4px 16px 0' }}>
        {COLUMNS.map((c) => {
          const isActive = c.key === active;
          const tone = `var(${c.cssVar})`;
          return (
            <button key={c.key} onClick={() => setActive(c.key)}
              style={{
                flex: 1, border: 'none', cursor: 'pointer', padding: '10px 0 12px',
                background: 'transparent',
                color: isActive ? tone : 'var(--ink-faded)',
                fontFamily: 'var(--font-display)', fontStyle: 'italic',
                fontSize: 17, fontWeight: 500, letterSpacing: '-0.01em',
                position: 'relative',
                transition: 'color var(--dur-fast)',
              }}>
              <span>{t(`columns.${c.key}.title`)}</span>
              <span className="tabular" style={{
                marginLeft: 6, fontFamily: 'var(--font-body)', fontStyle: 'normal',
                fontSize: 11, color: isActive ? tone : 'var(--ink-faded)', opacity: 0.7,
              }}>{SAMPLE_ITEMS[c.key].length}</span>
              <span style={{
                position: 'absolute', bottom: 0, left: '15%', right: '15%',
                height: 2, borderRadius: 1,
                background: isActive ? tone : 'transparent',
                transition: 'background var(--dur)',
              }} />
            </button>
          );
        })}
      </div>

      {/* Column subtitle */}
      <div style={{ padding: '14px 18px 4px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 11, color: 'var(--ink-faded)', letterSpacing: '0.02em' }}>
          {t(`columns.${active}.subtitle`)}
        </span>
        <span style={{ color: `var(${col.cssVar})`, opacity: 0.4 }}>{pui.iconArrow}</span>
      </div>

      {/* Items */}
      <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', padding: '0 18px 18px' }}>
        <ColumnSurface
          colKey={active}
          items={items}
          color={`var(${col.cssVar})`}
          t={t} locale={locale}
          onItemTap={onItemTap}
          onAdd={onAdd}
          hideTitle
        />
      </div>

      <BottomNav t={t} current="dashboard" onChange={(k) => { if (k === 'settings') onSettings && onSettings(); }} />
    </div>
  );
}

// ── B — ACCORDION ───────────────────────────────────────────────────────
function MobileAccordion({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light', extraTopBarActions }) {
  const [expanded, setExpanded] = React.useState('need');

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--paper-bg)', backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)' }}>
      <TopBar t={t} locale={locale} onLocale={onLocale} onSearch={() => {}} onSettings={onSettings} extraActions={extraTopBarActions} />

      <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', padding: '6px 14px 24px' }}>
        {COLUMNS.map((c) => {
          const isOpen = c.key === expanded;
          const items = SAMPLE_ITEMS[c.key];
          const tone = `var(${c.cssVar})`;
          return (
            <section key={c.key}
              style={{
                marginBottom: 10,
                background: `var(${c.wash})`,
                border: `1px solid var(${c.border})`,
                borderRadius: 12,
                overflow: 'hidden',
                transition: 'background var(--dur)',
              }}>
              <button onClick={() => setExpanded(isOpen ? null : c.key)}
                style={{
                  width: '100%', border: 'none', background: 'transparent',
                  padding: '12px 14px',
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
                  cursor: 'pointer', textAlign: 'left',
                  color: tone, fontFamily: 'inherit',
                }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0, flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500, fontSize: 20, letterSpacing: '-0.02em' }}>{t(`columns.${c.key}.title`)}</span>
                    <span className="tabular" style={{ fontSize: 11, color: 'var(--ink-faded)' }}>{items.length}</span>
                  </div>
                  {!isOpen && items[0] && (
                    <span style={{ fontSize: 12, color: 'var(--ink-faded)',
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {items.slice(0, 2).map((it) => it.name).join(' · ')}
                    </span>
                  )}
                </div>
                <span style={{
                  display: 'inline-flex', color: tone,
                  transform: isOpen ? 'rotate(90deg)' : 'rotate(0deg)',
                  transition: 'transform var(--dur)',
                }}>{pui.iconChevron}</span>
              </button>

              {isOpen && (
                <div style={{ padding: '0 14px 8px' }}>
                  {items.map((it) => (
                    <ItemCard key={it.id} item={it} onClick={() => onItemTap && onItemTap(it)} dense locale={locale} />
                  ))}
                  <AddRow promptText={t(`columns.${c.key}.promptCta`)} onClick={() => onAdd && onAdd(c.key)} color={tone} />
                </div>
              )}
            </section>
          );
        })}
      </div>

      <BottomNav t={t} current="dashboard" onChange={(k) => { if (k === 'settings') onSettings && onSettings(); }} />
    </div>
  );
}

// ── C — HORIZONTAL SWIPE / PAGER WITH PEEK ──────────────────────────────
function MobileSwipe({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light' }) {
  const [idx, setIdx] = React.useState(0);
  const railRef = React.useRef(null);

  // Snap each "page" to ~88% of the rail's width so the next column peeks.
  const peekRatio = 0.88;

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--paper-bg)', backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)' }}>
      <TopBar t={t} locale={locale} onLocale={onLocale} onSearch={() => {}} onSettings={onSettings} />

      {/* Page indicator (dots) */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '2px 0 10px' }}>
        {COLUMNS.map((c, i) => {
          const tone = `var(${c.cssVar})`;
          return (
            <button key={c.key} onClick={() => setIdx(i)}
              style={{
                width: i === idx ? 22 : 6, height: 6, borderRadius: 3,
                background: i === idx ? tone : 'var(--ink-whisper)',
                border: 'none', padding: 0, cursor: 'pointer',
                transition: 'width var(--dur), background var(--dur)',
              }} />
          );
        })}
      </div>

      {/* Rail */}
      <div ref={railRef} className="no-scrollbar"
        style={{ flex: 1, display: 'flex', overflowX: 'auto', scrollSnapType: 'x mandatory',
          padding: '0 0 0 16px', gap: 12 }}>
        {COLUMNS.map((c, i) => {
          const tone = `var(${c.cssVar})`;
          const items = SAMPLE_ITEMS[c.key];
          return (
            <div key={c.key} onClick={() => setIdx(i)}
              style={{
                flex: `0 0 calc(${peekRatio * 100}% - 16px)`,
                scrollSnapAlign: 'start',
                background: `var(${c.wash})`,
                border: `1.25px solid var(${c.border})`,
                borderRadius: 14,
                padding: '14px 14px 8px',
                display: 'flex', flexDirection: 'column',
                opacity: i === idx ? 1 : 0.6,
                transition: 'opacity var(--dur)',
                overflow: 'hidden',
              }}>
              <ColumnTitle titleKey={c.key} color={tone} t={t} size="md" />
              <div className="no-scrollbar" style={{ flex: 1, overflowY: 'auto', marginTop: 10 }}>
                {items.map((it) => (
                  <ItemCard key={it.id} item={it} onClick={(e) => { e.stopPropagation && e.stopPropagation(); onItemTap && onItemTap(it); }} locale={locale} />
                ))}
                <AddRow promptText={t(`columns.${c.key}.promptCta`)} onClick={(e) => { onAdd && onAdd(c.key); }} color={tone} />
              </div>
            </div>
          );
        })}
        {/* trailing spacer so the last column can snap fully */}
        <div style={{ flex: '0 0 16px' }} />
      </div>

      <BottomNav t={t} current="dashboard" onChange={(k) => { if (k === 'settings') onSettings && onSettings(); }} />
    </div>
  );
}

// ── D — FAN / STACK OF CARDS ────────────────────────────────────────────
// The three columns are sheets of paper stacked from top of the screen.
// Each column owns a tiny fixed tilt (kept across switches) so the stack
// always reads as a fan, not a deck. Back cards peek as colored "tabs"
// at the top — tap a peeking tab to bring that sheet to the front.
function MobileFan({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light', extraTopBarActions }) {
  const [active, setActive] = React.useState(0);
  // top-edge offsets BY DEPTH (0 = active, on top of stack):
  // the active card starts lowest (most content room); furthest-back peeks
  // at the very top.
  const topByDepth = [62, 32, 4];
  // Each COLUMN has its own immutable fan-tilt, so the silhouette doesn't
  // jolt when the active changes — only the z-order does.
  const tiltByCol = [-1.4, 0, 1.4];

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--paper-bg)', backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)', position: 'relative' }}>
      <TopBar t={t} locale={locale} onLocale={onLocale} onSearch={() => {}} onSettings={onSettings} extraActions={extraTopBarActions} />

      {/* helper hint */}
      <div style={{ padding: '0 20px 8px', fontSize: 11, color: 'var(--ink-faded)' }}>
        <span style={{ fontFamily: 'var(--font-hand)', fontSize: 17 }}>
          {locale === 'es' ? 'tocá una pestaña para traer esa hoja al frente' : 'tap a tab to bring that sheet to the front'}
        </span>
      </div>

      {/* card stack area */}
      <div style={{ flex: 1, position: 'relative', padding: '0 12px 64px', overflow: 'hidden' }}>
        {COLUMNS.map((c, i) => {
          // depth relative to active in fixed column-order (so each column
          // keeps its own tilt). depth 0 = top, 2 = furthest back.
          const depth = Math.abs(i - active);
          // BUT for actual z-stacking we want active on top regardless of i.
          // depth alone is symmetric (left and right neighbour both depth 1),
          // so disambiguate by giving the further-from-active card depth 2.
          const order = [active, ...[0,1,2].filter((x) => x !== active)];
          const dz = order.indexOf(i);
          const yTop = topByDepth[dz];
          const xInset = dz * 4;
          const scale = 1 - dz * 0.012;
          const tilt = tiltByCol[i] - tiltByCol[active]; // active card always upright
          const tone = `var(${c.cssVar})`;
          const tabBg = `var(${c.wash})`;
          const items = SAMPLE_ITEMS[c.key];
          const isTop = dz === 0;
          return (
            <div key={c.key} onClick={() => !isTop && setActive(i)}
              style={{
                position: 'absolute',
                top: yTop, left: 12 + xInset, right: 12 + xInset, bottom: 0,
                transform: `scale(${scale}) rotate(${tilt}deg)`,
                transformOrigin: '50% 100%',
                background: isTop ? 'var(--paper-bg)' : tabBg,
                backgroundImage: 'var(--paper-dots)',
                backgroundSize: 'var(--paper-dot-size)',
                border: `1.25px solid var(${c.border})`,
                borderBottom: 'none',
                borderTopLeftRadius: 18, borderTopRightRadius: 18,
                boxShadow: isTop
                  ? '0 -2px 0 rgba(255,255,255,0.4) inset, 0 -10px 24px -8px var(--paper-shadow), 0 16px 36px -8px var(--paper-shadow)'
                  : '0 -1px 0 rgba(255,255,255,0.3) inset, 0 4px 10px -4px var(--paper-shadow)',
                zIndex: 10 - dz,
                cursor: isTop ? 'default' : 'pointer',
                transition: 'transform var(--dur) var(--ease-spring), top var(--dur) var(--ease-spring), left var(--dur), right var(--dur), background var(--dur)',
                overflow: 'hidden',
                display: 'flex', flexDirection: 'column',
              }}>
              {/* tab/header */}
              <div style={{
                padding: isTop ? '14px 20px 10px' : '6px 20px 4px',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                borderBottom: isTop ? '1px solid var(--ink-whisper)' : 'none',
              }}>
                <div>
                  <span style={{
                    fontFamily: 'var(--font-display)', fontStyle: 'italic',
                    fontWeight: 500, fontSize: isTop ? 22 : 15,
                    letterSpacing: '-0.02em', color: tone, lineHeight: 1,
                  }}>{t(`columns.${c.key}.title`)}</span>
                  {isTop && (
                    <div style={{ fontSize: 11, color: 'var(--ink-faded)', marginTop: 3 }}>
                      {t(`columns.${c.key}.subtitle`)}
                    </div>
                  )}
                </div>
                <span className="tabular" style={{ fontSize: 11, color: 'var(--ink-faded)' }}>{items.length}</span>
              </div>
              {isTop && (
                <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', padding: '4px 20px 18px' }}>
                  {items.map((it) => (
                    <ItemCard key={it.id} item={it} onClick={() => onItemTap && onItemTap(it)} locale={locale} />
                  ))}
                  <AddRow promptText={t(`columns.${c.key}.promptCta`)} onClick={() => onAdd && onAdd(c.key)} color={tone} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <BottomNav t={t} current="dashboard" onChange={(k) => { if (k === 'settings') onSettings && onSettings(); }} />
    </div>
  );
}

Object.assign(window, { MobileTabs, MobileAccordion, MobileSwipe, MobileFan });

// ── MainDashboard — the actual product home.
//
// Default layout is the ACCORDION (vertical stack with all three columns in
// peripheral vision). A visible LayoutToggle button in the top bar swaps to
// the FAN view. The choice persists per user (here: localStorage).
//
// initialLayout overrides the persisted value — used in the canvas to show
// both states side-by-side as static artboards.
function MainDashboard({ t, locale, onLocale, onItemTap, onAdd, onSettings, theme = 'light', initialLayout }) {
  const STORAGE_KEY = 'i-need-it.layout';
  const [layout, setLayout] = React.useState(() => {
    if (initialLayout) return initialLayout;
    try { return localStorage.getItem(STORAGE_KEY) || 'accordion'; } catch (e) { return 'accordion'; }
  });
  const setAndSave = (l) => {
    setLayout(l);
    try { localStorage.setItem(STORAGE_KEY, l); } catch (e) {}
  };

  const toggle = <LayoutToggle layout={layout} onToggle={setAndSave} t={t} />;
  const Variant = layout === 'fan' ? MobileFan : MobileAccordion;

  return (
    <Variant
      t={t} locale={locale} onLocale={onLocale}
      onItemTap={onItemTap} onAdd={onAdd} onSettings={onSettings}
      theme={theme}
      extraTopBarActions={toggle}
    />
  );
}

Object.assign(window, { MainDashboard });
