// modal-screens.jsx — create / view / edit modal flows
//
// One modal for all three states. Mobile = bottom sheet (slides up from
// bottom, pinned to bottom of frame). Desktop = centered card with backdrop.
//
// The mode prop drives header copy and which fields start populated.
// mode: 'create' (empty form, header asks "¿Qué necesitas/quieres/deseas?")
//       'view'   (filled, read-only-ish with edit/complete/delete actions)
//       'edit'   (filled, editable)

// Shared form body. Renders inline on desktop, inside the sheet on mobile.
function ItemForm({ t, locale, colKey, item, isView = false }) {
  const tone = `var(${COLUMNS.find((c) => c.key === colKey).cssVar})`;

  // Defaults from the item when given; otherwise empty form.
  const initialTime = item?.time || (colKey === 'need' ? 'thisWeek' : colKey === 'want' ? 'thisMonth' : 'oneYear');
  const initialCurr = item?.cost?.currency || 'ars';
  const initialAmt  = item?.cost?.amount != null ? String(item.cost.amount) : '';
  const initialPlace = item?.place || '';
  const initialName = item?.name || '';
  const initialTags = item?.tags || [];

  // The chips menu mirrors the user's spec: a row of preset durations + an
  // optional "pick a date" chip that toggles a date input below.
  const timeChips = ['today', 'thisWeek', 'twoWeeks', 'thisMonth', 'threeMonths', 'sixMonths', 'oneYear', 'moreThanYear'];
  const currencies = ['ars', 'usd', 'eur', 'brl'];
  const tagOptions = ['health', 'home', 'hobby', 'work', 'family', 'travel', 'money', 'study', 'fitness'];

  const labelStyle = {
    fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase',
    color: 'var(--ink-faded)', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  };

  const fieldFrame = {
    border: '1px solid var(--ink-whisper)',
    borderRadius: 8,
    padding: '10px 12px',
    background: 'var(--paper-bg)',
    fontFamily: 'inherit',
    color: 'var(--ink)',
    fontSize: 15,
    width: '100%',
    outline: 'none',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* NAME */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={labelStyle}>
          <span>{t('form.nameLabel')}</span>
          <span style={{ color: tone, fontSize: 9.5 }}>{t('form.required')}</span>
        </div>
        <input
          type="text"
          defaultValue={initialName}
          placeholder={t(`columns.${colKey}.promptCta`)}
          style={{
            ...fieldFrame,
            fontFamily: 'var(--font-display)',
            fontStyle: 'italic',
            fontSize: 22,
            fontWeight: 500,
            letterSpacing: '-0.01em',
            color: 'var(--ink)',
            padding: '8px 12px',
          }}
        />
      </div>

      {/* TIME — chips row + date picker chip */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={labelStyle}>
          <span>{t('form.timeLabel')}</span>
          <span style={{ fontSize: 9.5, color: 'var(--ink-faded)' }}>{t('form.optional')}</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {timeChips.map((k) => (
            <Chip key={k} active={initialTime === k} color={tone}>
              {t(`time.${k}`)}
            </Chip>
          ))}
          <Chip color={tone} outlined>
            <span style={{ display: 'inline-flex', marginRight: 4 }}>{pui.iconTime}</span>
            {t('time.specificDate')}
          </Chip>
        </div>
      </div>

      {/* COST — number + currency dropdown stitched together */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={labelStyle}>
          <span>{t('form.costLabel')}</span>
          <span style={{ fontSize: 9.5, color: 'var(--ink-faded)' }}>{t('form.optional')}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'stretch', gap: 8 }}>
          <input
            type="text"
            inputMode="numeric"
            defaultValue={initialAmt}
            placeholder="0"
            className="tabular"
            style={{ ...fieldFrame, flex: 1 }}
          />
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '0 4px',
            border: '1px solid var(--ink-whisper)',
            borderRadius: 8,
            background: 'var(--paper-bg)',
            fontFamily: 'inherit',
          }}>
            {currencies.map((cur) => (
              <button key={cur}
                style={{
                  padding: '6px 10px',
                  border: 'none', cursor: 'pointer',
                  background: initialCurr === cur ? 'var(--ink)' : 'transparent',
                  color: initialCurr === cur ? 'var(--paper-bg)' : 'var(--ink-soft)',
                  borderRadius: 6,
                  fontSize: 11, fontWeight: 600,
                  letterSpacing: '0.04em',
                  fontFamily: 'inherit',
                  textTransform: 'uppercase',
                }}>{t(`currency.${cur}`)}</button>
            ))}
          </div>
        </div>
      </div>

      {/* PLACE */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={labelStyle}>
          <span>{t('form.placeLabel')}</span>
          <span style={{ fontSize: 9.5, color: 'var(--ink-faded)' }}>{t('form.optional')}</span>
        </div>
        <input
          type="text"
          defaultValue={initialPlace}
          placeholder={t('form.placePlaceholder')}
          style={fieldFrame}
        />
      </div>

      {/* TAGS */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={labelStyle}>
          <span>{t('form.tagsLabel')}</span>
          <span style={{ fontSize: 9.5, color: 'var(--ink-faded)' }}>{t('form.optional')}</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {tagOptions.map((tag) => (
            <Chip key={tag} active={initialTags.includes(tag)} color={tone}>{t(`tags.${tag}`)}</Chip>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── MobileModal (Bottom Sheet) ─────────────────────────────────────────
// Renders the column dashboard dimmed behind a sheet that slides up.
function MobileModal({ t, locale, onLocale, colKey, mode = 'create', item = null, theme = 'light' }) {
  const tone = `var(${COLUMNS.find((c) => c.key === colKey).cssVar})`;
  const headerTitle = mode === 'create'
    ? t(`columns.${colKey}.promptCta`)
    : (item?.name || t('form.edit'));

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', position: 'relative', background: 'var(--paper-bg)',
      color: 'var(--ink)', fontFamily: 'var(--font-body)', overflow: 'hidden' }}>

      {/* Faint preview of the dashboard underneath */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.45,
        backgroundImage: 'var(--paper-dots)', backgroundSize: 'var(--paper-dot-size)',
        background: 'var(--paper-bg)' }}>
        <TopBar t={t} locale={locale} onLocale={onLocale} onSearch={() => {}} onSettings={() => {}} />
        <div style={{ padding: '8px 18px' }}>
          <ColumnTitle titleKey={colKey} color={tone} t={t} size="lg" />
          <div style={{ marginTop: 14 }}>
            {SAMPLE_ITEMS[colKey].slice(0, 3).map((it) => (
              <ItemCard key={it.id} item={it} locale={locale} />
            ))}
          </div>
        </div>
      </div>

      {/* Scrim */}
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(20, 12, 6, 0.32)' }} />

      {/* Sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: 'var(--paper-bg)',
        backgroundImage: 'var(--paper-dots)',
        backgroundSize: 'var(--paper-dot-size)',
        borderTopLeftRadius: 22, borderTopRightRadius: 22,
        boxShadow: '0 -12px 30px rgba(0,0,0,0.18)',
        maxHeight: '88%',
        overflow: 'auto',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--ink-whisper)' }} />
        </div>

        {/* Sheet header */}
        <div style={{ padding: '4px 20px 8px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
          <div style={{ minWidth: 0 }}>
            {mode === 'create' ? (
              <div style={{
                fontFamily: 'var(--font-hand)',
                fontSize: 28, fontWeight: 500,
                color: tone, lineHeight: 1.1,
              }}>{headerTitle}</div>
            ) : (
              <div>
                <div style={{
                  fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
                  fontSize: 22, color: 'var(--ink)', letterSpacing: '-0.01em', lineHeight: 1.15,
                }}>{headerTitle}</div>
                <div style={{ fontSize: 11, color: tone, letterSpacing: '0.04em', textTransform: 'uppercase',
                  fontWeight: 600, marginTop: 4 }}>
                  {t(`columns.${colKey}.title`)}
                </div>
              </div>
            )}
          </div>
          <IconButton title={t('actions.close')}>{pui.iconClose}</IconButton>
        </div>

        {/* Form */}
        <div style={{ padding: '4px 20px 16px' }}>
          <ItemForm t={t} locale={locale} colKey={colKey} item={item} isView={mode === 'view'} />
        </div>

        {/* Footer actions */}
        <div style={{
          padding: '12px 20px 22px',
          borderTop: '1px solid var(--ink-whisper)',
          display: 'flex', alignItems: 'center', gap: 10,
          background: 'var(--paper-bg-tint)',
        }}>
          {mode !== 'create' && (
            <button style={ghostBtn('var(--ink-faded)')}>{t('form.delete')}</button>
          )}
          <div style={{ flex: 1 }} />
          {mode !== 'create' && (
            <button style={ghostBtn(tone)}>
              <span style={{ display: 'inline-flex', marginRight: 6, verticalAlign: 'middle' }}>{pui.iconCheck}</span>
              {t('form.complete')}
            </button>
          )}
          <button style={primaryBtn(tone)}>{t('form.save')}</button>
        </div>
      </div>
    </div>
  );
}

// ── DesktopModal — centered card on the dashboard backdrop ─────────────
function DesktopModal({ t, locale, onLocale, colKey, mode = 'view', item = null, theme = 'light' }) {
  const tone = `var(${COLUMNS.find((c) => c.key === colKey).cssVar})`;
  const headerTitle = mode === 'create'
    ? t(`columns.${colKey}.promptCta`)
    : (item?.name || t('form.edit'));

  return (
    <div data-theme={theme} style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden',
      background: 'var(--paper-bg)', color: 'var(--ink)', fontFamily: 'var(--font-body)' }}>

      {/* Faint dashboard underneath */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.45 }}>
        <DesktopDashboard t={t} locale={locale} onLocale={() => {}} />
      </div>

      <div style={{ position: 'absolute', inset: 0, background: 'rgba(20, 12, 6, 0.38)', backdropFilter: 'blur(2px)' }} />

      {/* Centered modal */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
        width: 560, maxHeight: '86%',
        background: 'var(--paper-bg)',
        backgroundImage: 'var(--paper-dots)',
        backgroundSize: 'var(--paper-dot-size)',
        borderRadius: 14,
        boxShadow: '0 30px 80px rgba(0,0,0,0.30), 0 8px 24px rgba(0,0,0,0.18)',
        border: '1.5px solid var(--ink-whisper)',
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* header */}
        <div style={{
          padding: '20px 26px 16px',
          borderBottom: '1px solid var(--ink-whisper)',
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12,
        }}>
          <div>
            {mode === 'create' ? (
              <div style={{
                fontFamily: 'var(--font-hand)',
                fontSize: 34, fontWeight: 500,
                color: tone, lineHeight: 1, marginBottom: 2,
              }}>{headerTitle}</div>
            ) : (
              <div>
                <div style={{
                  fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 500,
                  fontSize: 28, color: 'var(--ink)', letterSpacing: '-0.02em', lineHeight: 1.05,
                }}>{headerTitle}</div>
              </div>
            )}
            <div style={{ fontSize: 11, color: tone, letterSpacing: '0.06em', textTransform: 'uppercase',
              fontWeight: 600, marginTop: 6 }}>
              {t(`columns.${colKey}.title`)} · {t(`columns.${colKey}.subtitle`)}
            </div>
          </div>
          <IconButton title={t('actions.close')}>{pui.iconClose}</IconButton>
        </div>

        {/* form body */}
        <div className="no-scrollbar" style={{ flex: 1, overflow: 'auto', padding: '20px 26px' }}>
          <ItemForm t={t} locale={locale} colKey={colKey} item={item} isView={mode === 'view'} />
        </div>

        {/* footer */}
        <div style={{
          padding: '14px 26px 18px',
          borderTop: '1px solid var(--ink-whisper)',
          display: 'flex', alignItems: 'center', gap: 10,
          background: 'var(--paper-bg-tint)',
        }}>
          {mode !== 'create' && <button style={ghostBtn('var(--ink-faded)')}>{t('form.delete')}</button>}
          <div style={{ flex: 1 }} />
          <button style={ghostBtn('var(--ink-soft)')}>{t('form.cancel')}</button>
          {mode !== 'create' && (
            <button style={ghostBtn(tone)}>
              <span style={{ display: 'inline-flex', marginRight: 6, verticalAlign: 'middle' }}>{pui.iconCheck}</span>
              {t('form.complete')}
            </button>
          )}
          <button style={primaryBtn(tone)}>{t('form.save')}</button>
        </div>
      </div>
    </div>
  );
}

function primaryBtn(color) {
  return {
    background: color, color: 'var(--paper-bg)',
    border: 'none', padding: '9px 16px', borderRadius: 8, cursor: 'pointer',
    fontFamily: 'inherit', fontSize: 13, fontWeight: 600, letterSpacing: '0.02em',
  };
}
function ghostBtn(color) {
  return {
    background: 'transparent', color,
    border: 'none', padding: '9px 12px', borderRadius: 8, cursor: 'pointer',
    fontFamily: 'inherit', fontSize: 13, fontWeight: 500,
  };
}

Object.assign(window, { MobileModal, DesktopModal });
